create trigger type_check_art
  before INSERT
  on art
  for each row
  set NEW.type_fest = 'Art';

