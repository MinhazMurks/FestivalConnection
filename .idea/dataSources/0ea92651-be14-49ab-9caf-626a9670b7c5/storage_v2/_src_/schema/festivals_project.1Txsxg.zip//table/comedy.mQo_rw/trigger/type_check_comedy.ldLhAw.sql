create trigger type_check_comedy
  before INSERT
  on comedy
  for each row
  set NEW.type_fest = 'Comedy';

