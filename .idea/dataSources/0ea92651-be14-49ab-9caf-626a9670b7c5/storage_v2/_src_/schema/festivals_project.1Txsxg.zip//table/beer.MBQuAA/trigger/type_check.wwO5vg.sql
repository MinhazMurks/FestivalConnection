create trigger type_check
  before INSERT
  on beer
  for each row
  set NEW.type_fest = 'Beer';

