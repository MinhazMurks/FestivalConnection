create trigger type_check_music
  before INSERT
  on music
  for each row
  set NEW.type_fest = 'Music';

